interface RState {
    public String toString(Reservation r);
}

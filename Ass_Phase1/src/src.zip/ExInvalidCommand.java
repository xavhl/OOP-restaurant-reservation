public class ExInvalidCommand extends Exception {
	public ExInvalidCommand() {super("Invalid command!");}
	public ExInvalidCommand(String message) {super(message);}
}